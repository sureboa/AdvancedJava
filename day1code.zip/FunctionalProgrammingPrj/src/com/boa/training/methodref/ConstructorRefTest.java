package com.boa.training.methodref;

class Customer{
	private int id;
	private String name;
	private String email;
	public Customer(int id, String name, String email) {
		super();
		System.out.println("invoking constructor with 3 args");
		this.id = id;
		this.name = name;
		this.email = email;
	}
	public Customer() {
		super();
		System.out.println("invoking constructor without args");
	}
	public Customer(int id, String name) {
		super();
		System.out.println("invoking constructor with 2 args");
		this.id = id;
		this.name = name;
	}
	public Customer(int id) {
		super();
		System.out.println("invoking constructor with 1 arg");
		this.id = id;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + "]";
	}
	
	
}

@FunctionalInterface
interface CustomerFactory1{
	Customer createCustomer();
}

@FunctionalInterface
interface CustomerFactory2{
	Customer createCustomer(int id);
}
@FunctionalInterface
interface CustomerFactory3{
	Customer createCustomer(int id,String name);
}
@FunctionalInterface
interface CustomerFactory4{
	Customer createCustomer(int id,String name,String mail);
}
public class ConstructorRefTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CustomerFactory1 factory1=Customer::new;
		CustomerFactory2 factory2=Customer::new;
		CustomerFactory3 factory3=Customer::new;
		CustomerFactory4 factory4=Customer::new;
		
		System.out.println(factory1.createCustomer());
		System.out.println(factory2.createCustomer(1001));
		System.out.println(factory3.createCustomer(5001,"Ramesh"));
		System.out.println(factory4.createCustomer(6001,"Amar","amar@gmail.com"));
	}

}
