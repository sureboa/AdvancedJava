package com.boa.training.methodref;

import java.util.HashMap;
import java.util.Map;



class Person{
	private String name;
	private String gender;
	private int age;
	public Person(String name, String gender, int age) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", gender=" + gender + ", age=" + age + "]";
	}
	
	
}

class PersonList{
	private Map<String, Person> listOfPersons=new HashMap<String, Person>();
	
	PersonList() {
		listOfPersons.put("Arvind", new Person("Arvind","Male", 30));
		listOfPersons.put("Surya", new Person("Surya","Male", 28));
		listOfPersons.put("Priya", new Person("Priya","Female", 25));
	}
	
	public Person getPerson(String name) {
		return listOfPersons.get(name);
	}
	
}

class PersonUtility{
	public Person getPersonData(PersonList list,String name) {
		return list.getPerson(name);
	}
}

interface I{
	Person getData(PersonUtility utility,PersonList list,String name);
}

public class MethodRefTest3 {
public static void main(String[] args) {
	I i=(utility,list,name)->utility.getPersonData(list, name);
	PersonUtility utility=new PersonUtility();
	PersonList list=new PersonList();
	
	System.out.println(i.getData(utility, list, "Surya"));
	
	i=PersonUtility::getPersonData;
	System.out.println(i.getData(utility, list, "Surya"));
}
}
