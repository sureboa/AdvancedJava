package com.boa.training.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list=Arrays.asList(4,9,10,12,6);
		Stream<Integer> stream1=list.stream();
		
		Stream<Double> stream2=stream1.map(x->Math.sqrt(x));
		stream2.forEach(x->System.out.println(x));
		System.out.println("with chaining");
		list.stream().map(x->Math.sqrt(x)).forEach(x->System.out.println(x));
	}

}
