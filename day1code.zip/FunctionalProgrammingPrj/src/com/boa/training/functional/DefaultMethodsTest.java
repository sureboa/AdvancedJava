package com.boa.training.functional;

interface K{
	default void sample() {
		System.out.println("sample method of interface K");
	}
}
interface L{
	default void next() {
		System.out.println("next method of interface L");
	}
}

class M implements K,L{
	void test() {
		sample();
		next();
	}
}

public class DefaultMethodsTest {
public static void main(String[] args) {
	M m=new M();
	m.test();
}
}
