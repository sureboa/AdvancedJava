package com.boa.training.functional;

import java.util.HashMap;
import java.util.Map;

class PersonList{
	private Map<String, Person> listOfPersons=new HashMap<String, Person>();
	
	PersonList() {
		listOfPersons.put("Arvind", new Person("Arvind","Male", 30));
		listOfPersons.put("Surya", new Person("Surya","Male", 28));
		listOfPersons.put("Priya", new Person("Priya","Female", 25));
	}
	
	public Person getPerson(String name) {
		return listOfPersons.get(name);
	}
	
}

interface F{
	Person details(String name);
}
public class LambdaTest5 {
public static void main(String[] args) {
	PersonList list=new PersonList();
	F f=n->list.getPerson(n);
	System.out.println(f.details("Surya"));
}
}
