package com.boa.training.functional;

interface B{
	String test();
	default void printData() {
		System.out.println("data: "+test());
	}
}
interface C{
int compute(String s);	
}

interface D{
String compute(String s1,int i);
}
public class LambdaTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b=()->{
			return "Hello";
		};
		//can also be written as B b=()->"Hello";
		b.printData();
		C c=s->s.length();
		D d=(s,a)->s.substring(a);
		System.out.println(c.compute("hello world"));
		System.out.println(d.compute("testing", 4));
	}

}
