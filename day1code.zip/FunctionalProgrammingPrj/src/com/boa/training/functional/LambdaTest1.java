package com.boa.training.functional;

public class LambdaTest1 {
public static void main(String[] args) {
	Sample sample=s->"Welcome to Java 8 "+s;
	System.out.println(sample.message("Arvind"));
}
}
