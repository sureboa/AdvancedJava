package com.boa.training.functional;

interface J1{
	default void test() {
		System.out.println("test method of J1");
	}
}

interface J2{
	default void test() {
		System.out.println("test method of J2");
	}
}

class J3 implements J1,J2{
	public void test() {
		J1.super.test();
		J2.super.test();
		System.out.println("code added in j3");
		
	}
}

public class DefaultMethodsTest2 {
public static void main(String[] args) {
	J3 j3=new J3();
	j3.test();
	
}
}
