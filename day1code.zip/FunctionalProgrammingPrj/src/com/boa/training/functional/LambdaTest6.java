package com.boa.training.functional;
class Number{
	private int i;
	private int j;
	public Number(int i, int j) {
		super();
		this.i = i;
		this.j = j;
	}
	@Override
	public String toString() {
		return "Number [i=" + i + ", j=" + j + "]";
	}
	
}

interface G{
	Number data(int x,int y);
}

public class LambdaTest6 {
public static void main(String[] args) {
	G g=(a,b)->new Number(a,b);
	System.out.println(g.data(10, 20));
}
}
