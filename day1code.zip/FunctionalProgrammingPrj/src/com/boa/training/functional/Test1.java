package com.boa.training.functional;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Sample sample=new SampleImpl();
		System.out.println(sample.message("Arvind"));
	}

}
