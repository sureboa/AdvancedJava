package com.boa.training.functional;
interface R{
	static void method1() {
		System.out.println("static method1 of R");
	}
	static void method2() {
		System.out.println("static method2 of R");
	}
	default void method3() {
		System.out.println("default method3 of R");
	}
	default void method4() {
		System.out.println("default method4 of R");
	}
	void method5();
	
}

public class StaticMethodTest {
public static void main(String[] args) {
	R r=()->System.out.println("method5 of R");
	r.method3();
	r.method4();
	R.method1();
	R.method2();
	r.method5();
}
}
