package com.boa.training.functional;
@FunctionalInterface
interface I{
	String process(String a,String b);
	//int test();
}
interface J{
	int getData();
}

public class LambdaTest8 {
public static void main(String[] args) {
	I i1=getDetails();
	System.out.println(i1.process("hello", "world"));
	J j2=testData((x,y)->{
	System.out.println("invoking process method with parameters "+x+" and "+y);	
	return "Welcome "+x+" "+y;
	},"John","Hopkins");
	int data=j2.getData();
	System.out.println("data: "+data);
}

static I getDetails()
{
	return (x,y)->(x+" "+y).toUpperCase();
}

static J testData(I i,String s1,String s2) {
	String result=i.process(s1, s2);
	return ()->{
		System.out.println("invoking getData method ");
		return result.length()+5;//"Welcome John Hopkins".length()+5
	};
}
}
