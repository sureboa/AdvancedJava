package com.boa.training.functional;

interface A{
	int compute(int a,int b);
	default String test() {
		return "Hello";
	}
}
public class LambdaTest2 {
	public static void main(String[] args) {
		A a1=(a,b)->{
			System.out.println("first parameter: "+a);
			System.out.println("second parameter: "+b);
			return a+b;
		};
		System.out.println(a1.compute(10, 20));
		a1=(a,b)->a*b;
		System.out.println(a1.compute(10, 20));
		System.out.println(a1.test());
		a1=(a,b)->{
			if(a>b) return a; 
			else return b;
		};
		System.out.println(a1.compute(10, 20));
	}

}
