package com.boa.training.functional;

public class SampleImpl implements Sample{

	@Override
	public String message(String name) {
		// TODO Auto-generated method stub
		return "Testing "+name;
	}

}
