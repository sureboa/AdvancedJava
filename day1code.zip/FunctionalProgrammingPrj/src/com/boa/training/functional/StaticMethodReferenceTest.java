package com.boa.training.functional;

class Utility{
	static void method1(String s) {
		System.out.println("method1 with "+s+" as argument");
	}

	static String method2(String s) {
		System.out.println("method2 with "+s+" as argument");
		return s.toUpperCase();
	}

	static String method3(String s1,String s2) {
		System.out.println("method3 with "+s1+" and "+s2+" as arguments");
		return s1+" "+s2;
	}

}

interface K1{
	void test(String a);
}
interface K2{
	String test(String a);
}

interface K3{
	String test(String a,String b);
}


public class StaticMethodReferenceTest {
public static void main(String[] args) {
	//you are informing the test method of k1 will have the same logic as method1 in Utility
	K1 k1=Utility::method1; 
	//you are informing the test method of k2 will have the same logic as method2 in Utility
	K2 k2=Utility::method2;
	//you are informing the test method of k3 will have the same logic as method3 in Utility
	K3 k3=Utility::method3;
	k1.test("hello");
	System.out.println(k2.test("hello"));
	System.out.println(k3.test("hello", "world"));
}
}
