package com.boa.training.threads;

class M{
    
}

class Thread11 extends Thread{
    private M m;
    
    public Thread11(M m) {
        super();
        this.m = m;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        
        synchronized (m) {
            System.out.println(Thread.currentThread().getName()+" is going to invoke wait on m ");
            try {
                m.wait();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName()+" after being unblocked ");
        }
    
        
    }
    
}

public class WaitAndNotifyTest1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        M m=new M();
        Thread11 t11=new Thread11(m);
        t11.setName("test-thread");
        t11.start();
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        synchronized(m) {
        System.out.println("main thread is going to invoke notify on m");
        m.notify();
        System.out.println("main thread after invoking notify on m");
        }
        
    }

}