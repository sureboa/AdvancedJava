package com.boa.training.threads;

class Q{
     void display() {
         System.out.println(Thread.currentThread().getName()+" entering synchronized block");
         synchronized(this) {
        System.out.println("A");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("B");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("C");
         }
    }
}

class ThreadY extends Thread{
    private Q q;

    

    public ThreadY(Q q) {
        super();
        this.q = q;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        test();
        q.display();
    }
    
    void test() {
        System.out.println("X");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Y");
        
    }
    
}

public class ThreadTest8 {
public static void main(String[] args) {
    Q q=new Q();
    ThreadY firstThread=new ThreadY(q);
    ThreadY secondThread=new ThreadY(q);
    firstThread.setName("first-thread");
    secondThread.setName("second-thread");
    firstThread.start();
    secondThread.start();
}
}