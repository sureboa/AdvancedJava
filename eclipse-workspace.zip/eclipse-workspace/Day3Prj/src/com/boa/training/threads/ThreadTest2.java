package com.boa.training.threads;

class A implements Runnable{

    @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=1;i<=50;i++) {
            System.out.println("Inside thread "+Thread.currentThread()+" "+i);
        }
    }
    
}

public class ThreadTest2 {
public static void main(String[] args) {
    A a1=new A();
    Thread t1=new Thread(a1,"first-thread");
    Thread t2=new Thread(a1,"second-thread");
    Thread t3=new Thread(a1,"third-thread");
    t1.start();
    t2.start();
    t3.start();
}
}