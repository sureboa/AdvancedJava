package com.boa.training.threads;

class First implements Runnable{

    @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=1;i<=50;i++) {
            System.out.println("Inside "+Thread.currentThread()+" "+i);
        }
    }
    
}

class Second implements Runnable{

    @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=1;i<=50;i++) {
            System.out.println("Inside "+Thread.currentThread()+" "+i);
        }
    }
    
}

public class ThreadTest1 {
public static void main(String[] args) {
    First f=new First();
    Second s=new Second();
    
    Thread t1=new Thread(f);
    Thread t2=new Thread(s);
    t1.setName("first-thread");
    t2.setName("second-thread");
    t1.start();
    t2.start();
}
}