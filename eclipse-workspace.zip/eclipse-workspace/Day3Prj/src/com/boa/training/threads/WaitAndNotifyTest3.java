package com.boa.training.threads;

class O{
    
}

class Thread1111 extends Thread{
    private O o;
    
    
    
    public Thread1111(O o) {
        super();
        this.o = o;
    }



    @Override
    public void run() {
        // TODO Auto-generated method stub
        
        synchronized (o) {
            System.out.println(Thread.currentThread().getName()+" is going to invoke wait on o ");
            try {
                o.wait();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName()+" after being unblocked ");
        }
    
        
    }
    
}
class Thread1112 extends Thread{
    private O o;
    
    

    public Thread1112(O o) {
        super();
        this.o = o;
    }



    @Override
    public void run() {
        // TODO Auto-generated method stub
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        synchronized (o) {
            System.out.println(Thread.currentThread().getName()+" is going to invoke notify on o ");
            
                o.notify();
            
            System.out.println(Thread.currentThread().getName()+" after invoking notify on o ");
        }
    
        
    }
    
}
public class WaitAndNotifyTest3 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        O o=new O();
        Thread1111 t11=new Thread1111(o);
        Thread1111 t12=new Thread1111(o);
        Thread1112 t2=new Thread1112(o);
        t11.setName("T1");
        t12.setName("T2");
        t2.setName("T3");
        t11.start();
        t12.start();
        t2.start();
    
        
    }

}
