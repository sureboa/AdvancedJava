package com.boa.training.threads;

class ZThread extends Thread{
    @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=1;i<=50;i++) {
            System.out.println("inside  "+Thread.currentThread()+" "+i);
        }
    }
}

public class ThreadTest4 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        ZThread thread1=new ZThread();
        ZThread thread2=new ZThread();
        ZThread thread3=new ZThread();
        thread1.setName("zthread-1");
        thread2.setName("zthread-2");
        thread3.setName("zthread-3");
        thread1.start();
        thread2.start();
        thread3.start();
    }

}