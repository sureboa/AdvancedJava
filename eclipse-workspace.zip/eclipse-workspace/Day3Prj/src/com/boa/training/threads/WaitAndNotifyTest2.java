package com.boa.training.threads;

class N{
    
}

class Thread111 extends Thread{
    private N n;
    
    public Thread111(N n) {
        super();
        this.n = n;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        
        synchronized (n) {
            System.out.println(Thread.currentThread().getName()+" is going to invoke wait on n ");
            try {
                n.wait();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName()+" after being unblocked ");
        }
    
        
    }
    
}
class Thread112 extends Thread{
    private N n;
    
    public Thread112(N n) {
        super();
        this.n = n;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        synchronized (n) {
            System.out.println(Thread.currentThread().getName()+" is going to invoke notify on n ");
            
                n.notify();
            
            System.out.println(Thread.currentThread().getName()+" after invoking notify on n ");
        }
    
        
    }
    
}
public class WaitAndNotifyTest2 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        N n=new N();
        Thread111 t1=new Thread111(n);
        Thread112 t2=new Thread112(n);
        t1.setName("T1");
        t2.setName("T2");
        t1.start();
        t2.start();
        
    }

}