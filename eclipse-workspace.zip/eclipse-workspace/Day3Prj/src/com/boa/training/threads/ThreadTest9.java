package com.boa.training.threads;
class Account{
    void withdraw() {
        System.out.println(Thread.currentThread().getName()+" has started to withdraw");
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" has completed withdrawal");
    }
    
    void deposit() {
        System.out.println(Thread.currentThread().getName()+" has started to deposit");
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" has completed depositing");
    }
    
    void retrieveBalance() {
        System.out.println(Thread.currentThread().getName()+" has started to retrieve balance");
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" has completed retrieving balance");
    }
}

class DepositThread extends Thread{
    private Account account;

    public DepositThread(Account account) {
        super();
        this.account = account;
    }
    
    public void run() {
        //no other thread is allowed to deposit or withdraw at the same time
        synchronized (account) {
            account.deposit();
        }
    }
}

class WithdrawalThread extends Thread{
    private Account account;

    public WithdrawalThread(Account account) {
        super();
        this.account = account;
    }
    
    public void run() {
        //no other thread is allowed to deposit or withdraw at the same time
        synchronized (account) {
            account.withdraw();
        }
    }
}

class RetrieveBalanceThread extends Thread{
    private Account account;

    public RetrieveBalanceThread(Account account) {
        super();
        this.account = account;
    }
    
    public void run() {
        //no synchronized block
        //multiple threads are allowed to retrieve balance at the same time
            account.retrieveBalance();
        
    }
}
public class ThreadTest9 {
public static void main(String[] args) {
    Account account=new Account();
    for(int i=1;i<=5;i++) {
        DepositThread dt=new DepositThread(account);
        dt.setName("deposit-thread-"+i);
        dt.start();
    }
    for(int i=1;i<=5;i++) {
        WithdrawalThread wt=new WithdrawalThread(account);
        wt.setName("withdraw-thread-"+i);
        wt.start();
    }
    for(int i=1;i<=5;i++) {
        RetrieveBalanceThread rt=new RetrieveBalanceThread(account);
        rt.setName("retrieve-balance-thread-"+i);
        rt.start();
    }
}
}