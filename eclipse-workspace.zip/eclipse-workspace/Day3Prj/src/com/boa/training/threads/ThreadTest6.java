package com.boa.training.threads;
class B implements Runnable{

    @Override
    public void run() {
        // TODO Auto-generated method stub
        System.out.println(Thread.currentThread().getName()+" X");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" Y");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" Z");
        
    }
    
}

public class ThreadTest6 {
public static void main(String[] args) {
    B b=new B();
    Thread t1=new Thread(b);
    t1.setName("T-1");
    Thread t2=new Thread(b);
    t2.setName("T-2");
    t1.start();
    t2.start();
}
}