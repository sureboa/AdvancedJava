package com.boa.training.threads;

class P{
    synchronized void display() {
        System.out.println("A");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("B");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("C");
        
    }
}

class ThreadX extends Thread{
    private P p;

    public ThreadX(P p) {
        super();
        this.p = p;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        test();
        p.display();
    }
    
    void test() {
        System.out.println("X");
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Y");
        
    }
    
}

public class ThreadTest7 {
public static void main(String[] args) {
    P p=new P();
    ThreadX firstThread=new ThreadX(p);
    ThreadX secondThread=new ThreadX(p);
    firstThread.start();
    secondThread.start();
}
}