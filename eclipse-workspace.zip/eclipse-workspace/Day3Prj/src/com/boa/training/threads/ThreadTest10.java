package com.boa.training.threads;

class PThread extends Thread{
    public void run() {
        for(int i=1;i<=50;i++) {
            System.out.println("inside pthread "+i);
        }
    }
}
class QThread extends Thread{
    public void run() {
        for(int i=1;i<=50;i++) {
            System.out.println("inside qthread "+i);
        }
    }
}


public class ThreadTest10 {
public static void main(String[] args) {
PThread pThread=new PThread();
QThread qThread=new QThread();
pThread.start();
qThread.start();
for(int i=1;i<=50;i++) {
    System.out.println("inside main thread "+i);
}
}
}