package com.boa.training.threads;

class XThread extends Thread{

    @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=1;i<=50;i++) {
            System.out.println("inside xthread "+Thread.currentThread()+" "+i);
        }
    }
    
}

class YThread extends Thread{

    @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=1;i<=50;i++) {
            System.out.println("inside ythread "+Thread.currentThread()+" "+i);
        }
    }
    
}


public class ThreadTest3 {
public static void main(String[] args) {
    XThread t1=new XThread();
    YThread t2=new YThread();
    t1.setName("thread-one");
    t2.setName("thread-two");
    t1.start();
    t2.start();
}
}