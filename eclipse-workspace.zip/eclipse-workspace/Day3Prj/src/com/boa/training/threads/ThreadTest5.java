package com.boa.training.threads;

public class ThreadTest5 {
    public static void main(String[] args) {
        ZThread thread1=new ZThread();
        thread1.setName("thread-1");
        thread1.setPriority(Thread.MAX_PRIORITY);
        
        ZThread thread2=new ZThread();
        thread2.setName("thread-2");
        thread2.setPriority(Thread.MIN_PRIORITY);
        
        thread1.start();
        thread2.start();
        
    }

}