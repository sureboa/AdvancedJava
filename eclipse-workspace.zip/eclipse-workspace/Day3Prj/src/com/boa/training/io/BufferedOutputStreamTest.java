package com.boa.training.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        byte[] arr=new byte[1024];
        try(FileInputStream fin=new FileInputStream("c:/test/first.txt");
                BufferedInputStream bin=new BufferedInputStream(fin);
                FileOutputStream fout=new FileOutputStream("c:/test/third.txt",true);
                BufferedOutputStream bout=new BufferedOutputStream(fout)) {
            int c=bin.read(arr);
            bout.write(new String("\n").getBytes());
            while(c!=-1) {
                bout.write(arr);
                c=bin.read(arr);
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

    }

}