package com.boa.training.io;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class BufferedReaderTest {

	/*
	 * public static void main(String[] args) { // TODO Auto-generated method stub
	 * String file="c:/test/test.sql"; try(FileReader fr=new
	 * FileReader(file);BufferedReader br=new BufferedReader(fr)){ String line=null;
	 * while((line=br.readLine())!=null) { System.out.println(line); } } catch
	 * (FileNotFoundException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } catch (IOException e) { // TODO Auto-generated catch
	 * block e.printStackTrace(); }
	 * 
	 * }
	 */
	
	public static void main(String[] args) {
        // TODO Auto-generated method stub
        String file="c:/test/test.sql";
        try(FileReader fr=new FileReader(file);BufferedReader br=new BufferedReader(fr);
                FileWriter fw=new FileWriter("c:/test/sample.sql");
                PrintWriter pw=new PrintWriter(fw, true)){
            String line=null;
            while((line=br.readLine())!=null) {
                pw.println(line);
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}