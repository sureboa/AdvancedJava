package com.boa.training.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        byte[] arr=new byte[1024];
        try(FileInputStream fin=new FileInputStream("c:/test/first.txt");FileOutputStream fout=new FileOutputStream("c:/test/second.txt",true)) {
            int c=fin.read(arr);
            fout.write(new String("\n").getBytes());
            while(c!=-1) {
                fout.write(arr);
                c=fin.read(arr);
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

    }

}