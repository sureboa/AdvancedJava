package com.boa.training.io;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectReadTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        try(FileInputStream fin=new FileInputStream("c:/test/employees.dat");
                ObjectInputStream oin=new ObjectInputStream(fin)){
        	Object obj=oin.readObject();
        	while(true) {
                Employee emp=(Employee)obj;
                System.out.println(emp.getId()+"\t"+emp.getName()+"\t"+emp.getDesignation());
                obj=oin.readObject();
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }catch(EOFException e) {
            System.out.println("Finished reading all objects");
        } 
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}