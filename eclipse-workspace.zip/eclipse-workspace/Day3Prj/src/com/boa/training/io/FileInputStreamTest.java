package com.boa.training.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamTest {
	
	public static void main(String[] args) {
		/*
		 * try(FileInputStream fin=new FileInputStream("c:/test/first.txt")){
		 * 
		 * int c=fin.read(); while(c!=-1) { System.out.print((char)c); c=fin.read(); } }
		 * catch (FileNotFoundException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } catch (IOException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); }
		 */
		
		// TODO Auto-generated method stub
        byte[] arr=new byte[1024];
        try(FileInputStream fin=new FileInputStream("c:/test/first.txt")) {
            int c=fin.read(arr);
            while(c!=-1) {
                System.out.print(new String(arr));
                c=fin.read(arr);
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

    }

}
