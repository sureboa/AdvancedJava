package com.boa.training.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectWriteTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        try(FileOutputStream fout=new FileOutputStream("c:/test/employees.dat");
                ObjectOutputStream out=new ObjectOutputStream(fout)){
            Employee e1=new Employee(1001, "Arvind", "Developer");
            Employee e2=new Employee(1002, "Suresh", "Accountant");
            Employee e3=new Employee(1003, "Rajiv", "Architect");
            out.writeObject(e1);
            out.writeObject(e2);
            out.writeObject(e3);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}