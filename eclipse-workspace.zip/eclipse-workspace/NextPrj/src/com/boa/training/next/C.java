package com.boa.training.next;

public class C {
public void first() {
    System.out.println("first method of class C under com.boa.training.next package in nextprj");
}
public void second() {
    System.out.println("second method of class C under com.boa.training.next package in nextprj");
}
public void third() {
    System.out.println("third method of class C under com.boa.training.next package in nextprj");
}
}
