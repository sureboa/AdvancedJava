/**
 * 
 */
/**
 * 
 */
module fifthmodule {
	
	exports com.boa.training.three;
}