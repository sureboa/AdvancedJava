package com.boa.training.three;

public class Z {
	
	public void test() {
		System.out.println("Test from class Z");
	}

}
