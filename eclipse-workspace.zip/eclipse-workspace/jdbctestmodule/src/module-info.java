/**
 * 
 */
/**
 * 
 */
module jdbctestmodule {
	
	requires java.sql;
}