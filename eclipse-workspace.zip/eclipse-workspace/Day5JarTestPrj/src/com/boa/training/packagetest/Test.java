package com.boa.training.packagetest;

import com.boa.training.next.C;
import com.boa.training.sample.A;
import com.boa.training.sample.B;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a = new A();
		a.test();
		B b = new B();
		b.next();
		C c = new C();
		c.third();

	}

}
