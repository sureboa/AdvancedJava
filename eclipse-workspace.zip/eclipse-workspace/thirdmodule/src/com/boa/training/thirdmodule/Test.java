package com.boa.training.thirdmodule;

import com.boa.training.first.Sample;
import com.boa.training.second.Next;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Sample sample = new Sample();
		sample.print();
		Next next = new Next();
		next.print();

	}

}
