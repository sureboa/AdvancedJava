/**
 * 
 */
/**
 * 
 */
module thirdmodule {
	
	requires firstmodule;
}