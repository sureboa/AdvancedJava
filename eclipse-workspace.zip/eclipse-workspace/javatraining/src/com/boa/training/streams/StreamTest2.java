package com.boa.training.streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

class XX{
    static boolean isHigh(int a) {
        return a>=10;
    }
}

public class StreamTest2 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        List<Integer> list=Arrays.asList(4,9,10,12,6);
        Stream<Integer> stream1=list.stream();
        
        Predicate<Integer> isEven=x->x%2==0;
        System.out.println("Even numbers");
        stream1.filter(isEven).forEach(System.out::println);
        System.out.println("Checking whether >=0 using method reference");
        list.stream().filter(XX::isHigh).map(x->x*x).forEach(System.out::println);
        
    }

}
