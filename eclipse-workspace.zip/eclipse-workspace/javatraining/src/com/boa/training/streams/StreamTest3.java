package com.boa.training.streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

class XXX{
    static boolean isHigh(int a) {
        return a>=10;
    }
}

public class StreamTest3 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        List<String> list=Arrays.asList("apple","orange","mango","pine apple","banana");
        Stream<String> stream1=list.stream();
        
        Predicate<String> isEven=x->x.length()>6;
        System.out.println("large numbers");
        stream1.filter(isEven).forEach(System.out::println);
        System.out.println("Checking whether >=0 using method reference");
        list.stream().filter(XXX::isHigh).map(x->x*x).forEach(System.out::println);
        
    }

}
