package com.boa.training.functional;

public class TestWithAnonymousClass {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        //Anonymous class
        Sample sample=new Sample() {//equivalent to creating a class which implements Sample interface
            //and overriding the message method

            @Override
            public String message(String name) {
                // TODO Auto-generated method stub
                return "Testing with anonymous class "+name;
            }
            
        };
        System.out.println(sample.message("Arvind"));
    }

}


