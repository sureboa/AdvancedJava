package com.boa.training.functional;

import java.util.HashMap;
import java.util.Map;

class PersonList{
    private Map<String, Person> list=new HashMap<String, Person>();
    
    PersonList() {
        list.put("Arvind", new Person("Arvind","Male", 30));
        list.put("Surya", new Person("Surya","Male", 28));
        list.put("Priya", new Person("Priya","Female", 25));
    }
    
    public Person getPerson(String name) {
        return list.get(name);
    }
    
}

interface F{
    Person details(String name);
}
public class LambdaTest5 {
public static void main(String[] args) {
    PersonList list=new PersonList();
    F f=n->list.getPerson(n);
    System.out.println(f.details("Surya"));
}
}