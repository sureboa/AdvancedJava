package com.boa.training.functional;

public interface Sample {
    String message(String name);
}