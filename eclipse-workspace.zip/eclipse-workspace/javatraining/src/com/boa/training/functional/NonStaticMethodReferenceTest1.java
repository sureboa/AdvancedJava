package com.boa.training.functional;

class P {
    private int i;

    public P(int i) {
        super();
        this.i = i;
    }

    int compute(int a) {
        return i * a;
    }
}

interface Q{
    int test(P p,int v);
}

class S{
    int next(P p1,int value) {
        return p1.compute(value);
    }
}

public class NonStaticMethodReferenceTest1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        P p1=new P(5);
        System.out.println("using class method reference");
        Q q=P::compute;
        int result=q.test(p1, 3);
        System.out.println(result);
        System.out.println("using lambda expression");
        q=(p,v)->p.compute(v);
        result=q.test(p1, 3);
        System.out.println(result);
        System.out.println("using object method reference");
        S s=new S();
        q=s::next;
        result=q.test(p1, 3);
        System.out.println(result);
        
    }

}