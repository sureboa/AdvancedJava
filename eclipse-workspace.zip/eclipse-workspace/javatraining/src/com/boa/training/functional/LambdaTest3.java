
package com.boa.training.functional;

interface B{
    String test();
    default void printData() {
        System.out.println("data: "+test());
    }
}
public class LambdaTest3 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        B b=()->"Hello";
        b.printData();
    }

}