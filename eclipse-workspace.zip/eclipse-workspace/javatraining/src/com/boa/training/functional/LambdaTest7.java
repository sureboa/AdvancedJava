package com.boa.training.functional;

import java.util.Set;
import java.util.TreeSet;

interface H{
    String getMessage(String name);
}

public class LambdaTest7 {

    public static void main(String[] args) {
        doSomething(a->"Do well "+a, "Rakesh");
        doSomething(a->"welcome:"+a.toUpperCase(), "amar");
        Thread t=new Thread(()->{
            for(int i=1;i<=10;i++) {
                System.out.println("within thread: "+Thread.currentThread().getName()+" "+i);
            }
        });
        t.setName("First Thread");
        t.start();
        Set<Integer> s=new TreeSet<Integer>((a,b)->b.compareTo(a));
        s.add(10);
        s.add(12);
        s.add(6);
        System.out.println(s);
    }
    
    static void doSomething(H h,String n) {
        System.out.println("message: "+h.getMessage(n));
    }
}