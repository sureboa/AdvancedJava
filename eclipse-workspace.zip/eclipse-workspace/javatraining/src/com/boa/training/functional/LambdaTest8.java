package com.boa.training.functional;

interface I{
    String process(String a,String b);
}

public class LambdaTest8 {
public static void main(String[] args) {
    I i1=getData();
    System.out.println(i1.process("hello", "world"));
}

static I getData()
{
    return (x,y)->(x+" "+y).toUpperCase();
}
}