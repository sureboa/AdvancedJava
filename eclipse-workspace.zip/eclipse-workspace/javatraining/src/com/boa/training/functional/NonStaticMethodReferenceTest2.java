package com.boa.training.functional;

import java.util.Set;

interface T{
    String[] test(String s1,String s2);
}

public class NonStaticMethodReferenceTest2 {
public static void main(String[] args) {
    String s="the cat sat on the mat";
    T t1=String::split;
    System.out.println("using method reference");
    String[] arr=t1.test(s, " ");
    for(String a:arr) {
        System.out.println(a);
    }
    
    System.out.println("using lambda expression");
    t1=(s1,s2)->s1.split(s2);
    arr=t1.test(s, " ");
    for(String a:arr) {
        System.out.println(a);
    }
    
    
    
}
}