package com.boa.training.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTest2 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String url="jdbc:mysql://localhost:3306/trainingdb";
        String user="root";
        //String passwd="rps@12345";
        String passwd=System.getProperty("password");
        //System.out.println(passwd);
        String sql="insert into employee values(?,?,?)";
        try {
            //establishes connection with db
            Connection connection=DriverManager.getConnection(url, user, passwd);
            //creates statement object on which sql queries can be executed
            PreparedStatement pst=connection.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(args[0]));
            pst.setString(2, args[1]);
            pst.setString(3, args[2]);
            int count=pst.executeUpdate();
            if(count>0) {
                System.out.println("Number of rows inserted: "+count);
            }
            connection.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

    }

}