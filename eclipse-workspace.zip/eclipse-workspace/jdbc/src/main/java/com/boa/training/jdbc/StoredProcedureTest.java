package com.boa.training.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StoredProcedureTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String url="jdbc:mysql://localhost:3306/trainingdb";
        String user="root";
        String passwd="rps@12345";
        
        try {
            //establishes connection with db
            Connection connection=DriverManager.getConnection(url, user, passwd);
            CallableStatement cst=connection.prepareCall("call insertRec(?,?,?)");
            cst.setInt(1, Integer.parseInt(args[0]));
            cst.setString(2, args[1]);
            cst.setString(3, args[2]);
            cst.execute();
            System.out.println("stored procedure executed");
            connection.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

    }

}