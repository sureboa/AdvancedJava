package com.boa.training.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTest1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String url="jdbc:mysql://localhost:3306/trainingdb";
        String user="root";
        String passwd="rps@12345";
        String sql="select * from employee";
        try {
            //establishes connection with db
            Connection connection=DriverManager.getConnection(url, user, passwd);
            //creates statement object on which sql queries can be executed
            Statement statement=connection.createStatement();
            //executes query and returns resultset which contains list of rows
            ResultSet resultSet=statement.executeQuery(sql);
            while(resultSet.next()) {
                System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+
                        resultSet.getString(3));
            }
            connection.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

    }
}