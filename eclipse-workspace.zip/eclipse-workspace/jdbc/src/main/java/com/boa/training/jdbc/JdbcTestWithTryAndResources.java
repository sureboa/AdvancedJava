package com.boa.training.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTestWithTryAndResources {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String url="jdbc:mysql://localhost:3306/trainingdb";
        String user="root";
        String passwd="rps@12345";
        String sql="select * from employee";
        try(Connection connection=DriverManager.getConnection(url, user, passwd); 
        		FileInputStream fin= new FileInputStream("C:/test/first.txt")) {
            //establishes connection with db
             
            //creates statement object on which sql queries can be executed
            Statement statement=connection.createStatement();
            //executes query and returns resultset which contains list of rows
            ResultSet resultSet=statement.executeQuery(sql);
            while(resultSet.next()) {
                System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+
                        resultSet.getString(3));
            }
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        

    }

}