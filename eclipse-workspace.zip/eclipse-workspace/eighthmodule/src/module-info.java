/**
 * 
 */
/**
 * 
 */
module eighthmodule {
	
	requires transitive seventhmodule;
    exports com.boa.training.eighth;
}