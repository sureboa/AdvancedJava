package com.boa.training.eighth;

import com.boa.training.seventh.Sample;

public class Flyer {
	
	public void fly() {
		System.out.println("flying using flyer in eighth module ");
	}
	
	public void test() {
		System.out.println("testing seventh module");
		Sample s = new Sample();
		s.print();
		
	}

}
