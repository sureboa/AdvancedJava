package com.boa.training.exceptions;

class MyResource implements AutoCloseable{

    @Override
    public void close() throws Exception {
        // TODO Auto-generated method stub
        System.out.println("closing myresource");
    }

    @Override
    public String toString() {
        return "MyResource []";
    }
    
    public void test() {
        System.out.println("started testing MyResource");
        throw new RuntimeException("unable to complete testing MyResource");
    }
    
}

public class ResourceTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        try(MyResource res=new MyResource()){
            System.out.println("doing something with "+res);
            res.test();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}