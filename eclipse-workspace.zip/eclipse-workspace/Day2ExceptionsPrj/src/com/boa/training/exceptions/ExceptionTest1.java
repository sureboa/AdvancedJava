package com.boa.training.exceptions;

public class ExceptionTest1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        try {
            int x=Integer.parseInt(args[0]);
            int y=Integer.parseInt(args[1]);
            System.out.println(x/y);
        }catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("insufficient arguments");
        }catch (ArithmeticException e) {
            System.out.println("Divide by zero error");
        }catch (NumberFormatException e) {
            System.out.println("Invalid number format");
        }finally {
            System.out.println("within finally");
        }
    }

}