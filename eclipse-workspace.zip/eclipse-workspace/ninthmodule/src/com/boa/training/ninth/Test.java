package com.boa.training.ninth;

import com.boa.training.eighth.Flyer;
import com.boa.training.seventh.Sample;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Flyer flyer = new Flyer();
		flyer.fly();
		flyer.test();
		
		Sample sample = new Sample();
		sample.print();

	}

}
