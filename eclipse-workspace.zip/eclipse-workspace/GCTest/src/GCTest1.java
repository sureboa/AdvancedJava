class A{
    private int i;

    public A(int i) {
        super();
        this.i = i;
    }

    @Override
    protected void finalize() throws Throwable {
        // TODO Auto-generated method stub
        System.out.println("removing the object with value: "+i);
    }
    
}
public class GCTest1 {
    public static void main(String[] args) {
        A a1=new A(10);
        A a2=a1;
        a1=null;
        a2=new A(20);
        //a2=null;
        System.gc();//will trigger a gc
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}