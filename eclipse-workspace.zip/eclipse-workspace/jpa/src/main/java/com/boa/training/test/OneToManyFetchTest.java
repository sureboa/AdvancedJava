package com.boa.training.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.boa.training.domain.Address;
import com.boa.training.domain.Customer;

public class OneToManyFetchTest {
public static void main(String[] args) {
    EntityManagerFactory factory=Persistence.createEntityManagerFactory("test-unit"); //datasource
    EntityManager em=factory.createEntityManager();//session to interact with datasource
    String jpaQL="select c from Customer c";
    Query query=em.createQuery(jpaQL);
    List<Customer> customers=query.getResultList();
    for(Customer c:customers) {
        System.out.println("customer detail");
        System.out.println(c.getCustId()+"\t"+c.getName()+"\t"+c.getEmail());
        System.out.println("Addresses for this customer");
        List<Address> addresses=c.getAddresses();
        for(Address a:addresses) {
            System.out.println(a.getAddressId()+"\t"+a.getLocation()+"\t"+a.getCity());
        }
    }
    em.close();
    factory.close();
}
}