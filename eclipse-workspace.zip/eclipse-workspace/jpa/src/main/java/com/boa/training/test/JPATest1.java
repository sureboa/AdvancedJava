package com.boa.training.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.boa.training.domain.Employee;

public class JPATest1 {
public static void main(String[] args) {
    EntityManagerFactory factory=Persistence.createEntityManagerFactory("test-unit"); //datasource
    EntityManager em=factory.createEntityManager(); // session to interact with datasource
    Employee e1=new Employee(1011, "Anand", "Developer");
    Employee e2=new Employee(1012, "Sam", "ITA");
    Employee e3=new Employee(1013, "Arav", "Developer");
    Employee e4=new Employee(1014, "Sanju", "Tester");
    EntityTransaction tx= em.getTransaction();
    tx.begin();
    em.persist(e1);
    em.persist(e2);
    em.persist(e3);
    em.persist(e4);
    tx.commit();
    System.out.println("rows inserted");
    em.close();
    factory.close();
}
}