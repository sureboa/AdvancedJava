package com.boa.training.test;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.boa.training.domain.Address;
import com.boa.training.domain.Customer;

public class OneToManyInsertTest {
public static void main(String[] args) {
    EntityManagerFactory factory=Persistence.createEntityManagerFactory("test-unit"); //datasource
    EntityManager em=factory.createEntityManager();//session to interact with datasource
    Customer c1=new Customer(1013, "Surya", "surya@gmail.com");
    Customer c2=new Customer(1014, "Ramesh", "ramesh@hotmail.com");
    Customer c3=new Customer(1015, "Priya", "priya@yahoo.com");
    
    List<Address> addressList1=Arrays.asList(new Address(5001, "Hebbal", "Bangalore"),
            new Address(5002, "Panjakutta", "Hyderabad"),new Address(5003, "Sector-17", "Noida"));
    List<Address> addressList2=Arrays.asList(new Address(5004, "Bandra East", "Mumbai"),
            new Address(5005, "Saidapet", "Chennai"));
    List<Address> addressList3=Arrays.asList(new Address(5006, "Vinoba Nagar", "Mysore"),
            new Address(5007, "Hinjewadi", "Pune"));
    
    c1.setAddresses(addressList1);
    c2.setAddresses(addressList2);
    c3.setAddresses(addressList3);
    EntityTransaction tx= em.getTransaction();
    tx.begin();
    em.persist(c1);
    em.persist(c2);
    em.persist(c3);
    tx.commit();
    System.out.println("rows inserted");
    em.close();
    factory.close();
}
}