package com.boa.training.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name ="customer_tbl")
public class Customer {
    @Id
    @Column(name="cust_id")
    private int custId;
    private String name;
    private String email;
    
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "c_id")
    private List<Address> addresses;

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    public Customer(int custId, String name, String email) {
        super();
        this.custId = custId;
        this.name = name;
        this.email = email;
    }

    public Customer() {
        super();
        // TODO Auto-generated constructor stub
    }

    
    
}