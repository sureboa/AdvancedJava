/**
 * 
 */
/**
 * 
 */
module seventhmodule {
	
	exports com.boa.training.seventh;
}