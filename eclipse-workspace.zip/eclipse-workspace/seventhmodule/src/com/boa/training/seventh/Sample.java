package com.boa.training.seventh;

public class Sample {
	
public void print() {
    System.out.println("print method of Sample under com.boa.training.seventh in seventhmodule");
}

}
