package com.boa.training.test;

import com.boa.training.next.C;

public class TestLibrary {
public static void main(String[] args) {
    C c=new C();
    c.third();
}
}