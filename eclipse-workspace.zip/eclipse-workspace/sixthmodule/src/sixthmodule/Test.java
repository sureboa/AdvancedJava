package sixthmodule;

import com.boa.training.one.X;
import com.boa.training.three.Z;
import com.boa.training.two.Y;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		X x1= new X();
		x1.test();
		
		Y y1 = new Y();
		y1.test();
		
		Z z1= new Z();
		z1.test();

	}

}
