package com.boa.training.first;

public class Sample {
	
public void print() {
    System.out.println("print method of Sample under com.boa.training.first in module-first");
}

}
