package com.boa.training.second;

public class Next {
    public void print() {
        System.out.println("print method of Next under com.boa.training.second in module-first");
    }
}