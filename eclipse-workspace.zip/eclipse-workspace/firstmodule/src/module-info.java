/**
 * 
 */
/**
 * 
 */
module firstmodule {
	
	exports com.boa.training.first;
	exports com.boa.training.second to thirdmodule,secondmodule;
}