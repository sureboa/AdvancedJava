package com.boa.training.threads;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableTest2 {
    
    public static void main(String[] args) {
        int[] arr= {42,63,80,58,12,37,67,45};
        Map<String, Future<Integer>> taskList=new HashMap<>();
        ExecutorService service=Executors.newFixedThreadPool(5);
        for(int i:arr) {
            CallableTask task=new CallableTask(i, "Task-"+i);
            Future<Integer> future=service.submit(task);
            taskList.put(task.getName(), future);
            
        }
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        taskList.forEach((taskName,future)->{
            try {
                System.out.println("return value for "+taskName+":"+future.get());
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ExecutionException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        });
        service.shutdown();
    }

}