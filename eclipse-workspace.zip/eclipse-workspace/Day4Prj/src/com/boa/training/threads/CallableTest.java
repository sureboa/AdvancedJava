package com.boa.training.threads;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class CallableTask implements Callable<Integer>{
    private int n;
    private String name;
    

    @Override
    public Integer call() throws Exception {
        // TODO Auto-generated method stub
        
        int sum=0;
        for(int i=1;i<=n;i++) {
            System.out.println("running task "+name+" with "+i);
            sum+=i;
            Thread.sleep(100);
        }
        return sum;
    }


    public CallableTask(int n, String name) {
        super();
        this.n = n;
        this.name = name;
    }


    public int getN() {
        return n;
    }


    public void setN(int n) {
        this.n = n;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }
    
}

public class CallableTest {
public static void main(String[] args) {
    ExecutorService service=Executors.newFixedThreadPool(2);
    CallableTask task1=new CallableTask(40, "First");
    Future<Integer> future1=service.submit(task1);
    CallableTask task2=new CallableTask(30, "Second");
    Future<Integer> future2=service.submit(task2);

    try {
        System.out.println("return value from task1: "+future1.get());
        System.out.println("return value from task2: "+future2.get());
    } catch (InterruptedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (ExecutionException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
    service.shutdown();
    
}
}