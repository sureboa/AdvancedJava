package com.boa.training.threads;

class A{
    
}
class B{
    
}

class FirstThread extends Thread{
    private A a;
    private B b;
    public FirstThread(A a, B b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    public void run() {
        System.out.println("First Thread is going to lock object a");
        synchronized (a) {
            System.out.println("First Thread has locked object a");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println("First Thread is going to lock object b");
            synchronized (b) {
                System.out.println("First Thread has locked object b");
            }
        }
    }
}


/*
 * class SecondThread extends Thread{ private A a; private B b; public
 * SecondThread(A a, B b) { super(); this.a = a; this.b = b; }
 * 
 * public void run() {
 * System.out.println("Second Thread is going to lock object b"); synchronized
 * (b) { System.out.println("Second Thread has locked object b"); try {
 * Thread.sleep(500); } catch (InterruptedException e) { // TODO Auto-generated
 * catch block e.printStackTrace(); }
 * System.out.println("Second Thread is going to lock object a"); synchronized
 * (a) { System.out.println("Second Thread has locked object a"); } } } }
 */

class SecondThread extends Thread{
    private A a;
    private B b;
    public SecondThread(A a, B b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    public void run() {
        System.out.println("Second Thread is going to lock object b");
        synchronized (b) {
            System.out.println("Second Thread has locked object b");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println("Second Thread is going to lock object a");
            synchronized (a) {
                System.out.println("Second Thread has locked object a");
            }
        }
    }
}

public class DeadLockTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        A a1=new A();
        B b1=new B();
        FirstThread firstThread=new FirstThread(a1, b1);
        SecondThread secondThread=new SecondThread(a1, b1);
        firstThread.setName("first-thread");
        secondThread.setName("second-thread");
        firstThread.start();
        secondThread.start();

    }

}