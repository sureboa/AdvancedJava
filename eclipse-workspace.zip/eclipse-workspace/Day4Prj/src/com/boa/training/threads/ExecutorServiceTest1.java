package com.boa.training.threads;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class X implements Runnable{
    private String name;
    
    public X(String name) {
        super();
        this.name = name;
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=1;i<=50;i++) {
            System.out.println("running task "+name+" "+i);
        }
        
    }
    
}

public class ExecutorServiceTest1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        ExecutorService service=Executors.newFixedThreadPool(3);
        for(int i=1;i<=5;i++) {
            X x=new X("task-"+i);
            service.execute(x);
        }
        service.shutdown();
    }

}