package com.boa.training.threads;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class Account{
    void withdraw() {
        System.out.println(Thread.currentThread().getName()+" has started to withdraw");
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" has completed withdrawal");
    }
    
    void deposit() {
        System.out.println(Thread.currentThread().getName()+" has started to deposit");
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" has completed depositing");
    }
    
    void retrieveBalance() {
        System.out.println(Thread.currentThread().getName()+" has started to retrieve balance");
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()+" has completed retrieving balance");
    }
}

class DepositThread extends Thread{
    private Account account;
    private ReadWriteLock lock;

    
    
    public DepositThread(Account account, ReadWriteLock lock) {
        super();
        this.account = account;
        this.lock = lock;
    }



    public void run() {
        
            lock.writeLock().lock();
            account.deposit();
            lock.writeLock().unlock();
        
    }
}

class WithdrawalThread extends Thread{
    private Account account;
    private ReadWriteLock lock;

    public WithdrawalThread(Account account,ReadWriteLock lock) {
        super();
        this.account = account;
        this.lock=lock;
    }
    
    public void run() {
        //no other thread is allowed to deposit or withdraw at the same time
            lock.writeLock().lock();
            account.withdraw();
            lock.writeLock().unlock();
    }
}

class RetrieveBalanceThread extends Thread{
    private Account account;
    private ReadWriteLock lock;
    
    
    public RetrieveBalanceThread(Account account, ReadWriteLock lock) {
        super();
        this.account = account;
        this.lock = lock;
    }


    public void run() {
            lock.readLock().lock();
            account.retrieveBalance();
            lock.readLock().unlock();
        
    }
}
public class ReadWriteLockTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        Account account=new Account();
        ReadWriteLock lock=new ReentrantReadWriteLock();
        
        for(int i=1;i<=5;i++) {
            WithdrawalThread wt=new WithdrawalThread(account, lock);
            wt.setName("withdraw-thread-"+i);
            wt.start();
        }
        for(int i=1;i<=5;i++) {
            DepositThread dt=new DepositThread(account, lock);
            dt.setName("deposit-thread-"+i);
            dt.start();
        }
        
        for(int i=1;i<=10;i++) {
            RetrieveBalanceThread rbt=new RetrieveBalanceThread(account, lock);
            rbt.setName("retrieve-balance-thread-"+i);
            rbt.start();
        }
    }

}