package com.boa.training.next;

public class C {
public void third() {
    System.out.println("third method of C");
}
}