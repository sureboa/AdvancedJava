package com.boa.training.sample;

public class A {
    public void test() {
        System.out.println("test method of A");
    }
}