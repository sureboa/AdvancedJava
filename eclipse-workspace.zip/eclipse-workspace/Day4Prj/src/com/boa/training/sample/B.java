package com.boa.training.sample;

public class B {
public void next() {
    System.out.println("next method of B");
}
}