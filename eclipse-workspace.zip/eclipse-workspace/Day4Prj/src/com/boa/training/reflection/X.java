package com.boa.training.reflection;

public class X {
    @MyAnnotation
    public void method1() {
        System.out.println("method1 of X");
    }

    @MyAnnotation(data = "sample")
    public void method2() {
        System.out.println("method2 of X");
    }
    
    @MyAnnotation(data = "testing",value = 25)
    public void method3() {
        System.out.println("method3 of X");
    }
    @MyAnnotation(55) //In any annotation , if the attribute name is not specified, it takes value as 
    //the default attribute
    public void method4() {
        System.out.println("method4 of X");
    }
}