package com.boa.training.reflection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class A{
    public void test() {
        System.out.println("test method of A");
    }
}

class B{
    public void test() {
        System.out.println("test method of B");
    }   
}

public class RefTest1 {
public static void main(String[] args) {
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Enter the class name");
    String className=null;
    try {
        className = br.readLine();
        System.out.println("classname: "+className);
        Class clz=Class.forName(className);//load the class into memory
        Object obj=clz.getDeclaredConstructor().newInstance();
        Method method=clz.getMethod("test");//retrieve test method of the class
        method.invoke(obj);//invoke the test method using the object obj
    } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (ClassNotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (InstantiationException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (IllegalAccessException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (IllegalArgumentException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (InvocationTargetException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (NoSuchMethodException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (SecurityException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
    
}
}