package com.boa.training.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class Sample{
    int add(int a,int b) {
        return a+b;
    }
    
    String process(String s1,String s2)
    {
        return (s1+" "+s2).toUpperCase();
    }
}

public class RefTest2 {
    public static void main(String[] args) {
        String className=args[0];
        try {
            Class clz=Class.forName(className);
            Object obj=clz.getDeclaredConstructor().newInstance();
            Method[] methods=clz.getDeclaredMethods();
            for(Method method:methods) {
                if(method.getName().equals("add")) {
                    Object retValue=method.invoke(obj, 10,20);
                    System.out.println("return value from add: "+retValue);
                }
                else if(method.getName().equals("process")) {
                    Object retValue=method.invoke(obj, "hello","world");
                    System.out.println("return value from process: "+retValue);
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}