package com.boa.training.reflection;

class P{
    void print() {
        System.out.println("print method of P");
    }
}

class Q extends P{
	@Override
    void print() {
        System.out.println("print method of Q");
    }
}

public class OverrideTest {
public static void main(String[] args) {
    P p=new Q();
    p.print();
    p=new P();
    p.print();
}
}