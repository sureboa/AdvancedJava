package com.boa.training.reflection;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class RefTest4 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        try {
            Class clz=Class.forName("com.boa.training.reflection.Data");
            Object obj=clz.getDeclaredConstructor().newInstance();
            Method method=clz.getMethod("print");
            method.invoke(obj);
            Field field=clz.getDeclaredField("i");
            field.setAccessible(true);
            field.set(obj, 15);
            field=clz.getDeclaredField("j");
            field.setAccessible(true);
            field.set(obj, 43.78);
            field=clz.getDeclaredField("s");
            field.setAccessible(true);
            field.set(obj, "welcome");
            
            method.invoke(obj);
            
            method=clz.getDeclaredMethod("doSomething", String.class);
            method.setAccessible(true);
            method.invoke(obj, "-----test-----");
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException | NoSuchFieldException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        

    }

}