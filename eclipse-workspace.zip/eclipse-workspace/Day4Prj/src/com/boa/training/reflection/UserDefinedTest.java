package com.boa.training.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class UserDefinedTest {
    public static void main(String[] args) {
        process(new X());
    }

    static void process(X x) {
        Class clz=x.getClass();
        try {
            Object obj=clz.getConstructor().newInstance();
            Method method1=clz.getMethod("method1");
            MyAnnotation method1Annotation=method1.getAnnotation(MyAnnotation.class);
            method1.invoke(obj);
            System.out.println("additional info for method1");
            System.out.println("value: "+method1Annotation.value()+"\tdata:"+method1Annotation.data());
            
            Method method2=clz.getMethod("method2");
            MyAnnotation method2Annotation=method2.getAnnotation(MyAnnotation.class);
            method2.invoke(obj);
            System.out.println("additional info for method2");
            System.out.println("value: "+method2Annotation.value()+"\tdata:"+method2Annotation.data());
            
            
            Method method3=clz.getMethod("method3");
            MyAnnotation method3Annotation=method3.getAnnotation(MyAnnotation.class);
            method3.invoke(obj);
            System.out.println("additional info for method3");
            System.out.println("value: "+method3Annotation.value()+"\tdata:"+method3Annotation.data());
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
}