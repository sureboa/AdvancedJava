/**
 * 
 */
/**
 * 
 */
module fourthmodule {
	
	exports com.boa.training.one;
	exports com.boa.training.two;
}