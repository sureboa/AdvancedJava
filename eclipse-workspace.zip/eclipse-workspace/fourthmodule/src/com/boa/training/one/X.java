package com.boa.training.one;

public class X {
	
	public void test() {
		System.out.println("Test from Class X");
	}

}
