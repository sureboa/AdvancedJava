package com.boa.training.two;

public class Y {
	
	public void test() {
		System.out.println("Test from Class Y");
	}

}
