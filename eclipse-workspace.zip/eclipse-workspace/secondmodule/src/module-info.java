/**
 * 
 */
/**
 * 
 */
module secondmodule {
	
	requires firstmodule;
}